/****************************************************************************
** Meta object code from reading C++ file 'commande.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../commande.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'commande.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "onCalendarDateChanged",
    "",
    "onExportCalendar",
    "updateStatistics",
    "updateCalendarHighlights",
    "displayOrdersForUpdate",
    "applyAdvancedFilters",
    "clearAdvancedFilters",
    "checkForNotifications",
    "onArduinoTemperatureReceived",
    "temperature",
    "humidity",
    "onArduinoErrorOccurred",
    "error",
    "onArduinoConnectedStatusChanged",
    "connected",
    "connectToArduino",
    "disconnectFromArduino",
    "displayEmailHistory",
    "resendEmailFromHistory",
    "clearEmailHistory",
    "filterEmailHistory",
    "sortEmailHistory",
    "column",
    "searchOrdersList",
    "sortOrdersList",
    "exportListToPDF"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  140,    2, 0x08,    1 /* Private */,
       3,    0,  141,    2, 0x08,    2 /* Private */,
       4,    0,  142,    2, 0x08,    3 /* Private */,
       5,    0,  143,    2, 0x08,    4 /* Private */,
       6,    0,  144,    2, 0x08,    5 /* Private */,
       7,    0,  145,    2, 0x08,    6 /* Private */,
       8,    0,  146,    2, 0x08,    7 /* Private */,
       9,    0,  147,    2, 0x08,    8 /* Private */,
      10,    2,  148,    2, 0x08,    9 /* Private */,
      13,    1,  153,    2, 0x08,   12 /* Private */,
      15,    1,  156,    2, 0x08,   14 /* Private */,
      17,    0,  159,    2, 0x08,   16 /* Private */,
      18,    0,  160,    2, 0x08,   17 /* Private */,
      19,    0,  161,    2, 0x08,   18 /* Private */,
      20,    0,  162,    2, 0x08,   19 /* Private */,
      21,    0,  163,    2, 0x08,   20 /* Private */,
      22,    0,  164,    2, 0x08,   21 /* Private */,
      23,    1,  165,    2, 0x08,   22 /* Private */,
      25,    0,  168,    2, 0x08,   24 /* Private */,
      26,    0,  169,    2, 0x08,   25 /* Private */,
      27,    0,  170,    2, 0x08,   26 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Float, QMetaType::Float,   11,   12,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'onCalendarDateChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onExportCalendar'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateStatistics'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateCalendarHighlights'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'displayOrdersForUpdate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'applyAdvancedFilters'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'clearAdvancedFilters'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'checkForNotifications'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onArduinoTemperatureReceived'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<float, std::false_type>,
        QtPrivate::TypeAndForceComplete<float, std::false_type>,
        // method 'onArduinoErrorOccurred'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'onArduinoConnectedStatusChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'connectToArduino'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'disconnectFromArduino'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'displayEmailHistory'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'resendEmailFromHistory'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'clearEmailHistory'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'filterEmailHistory'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sortEmailHistory'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'searchOrdersList'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sortOrdersList'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'exportListToPDF'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onCalendarDateChanged(); break;
        case 1: _t->onExportCalendar(); break;
        case 2: _t->updateStatistics(); break;
        case 3: _t->updateCalendarHighlights(); break;
        case 4: _t->displayOrdersForUpdate(); break;
        case 5: _t->applyAdvancedFilters(); break;
        case 6: _t->clearAdvancedFilters(); break;
        case 7: _t->checkForNotifications(); break;
        case 8: _t->onArduinoTemperatureReceived((*reinterpret_cast< std::add_pointer_t<float>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<float>>(_a[2]))); break;
        case 9: _t->onArduinoErrorOccurred((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 10: _t->onArduinoConnectedStatusChanged((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 11: _t->connectToArduino(); break;
        case 12: _t->disconnectFromArduino(); break;
        case 13: _t->displayEmailHistory(); break;
        case 14: _t->resendEmailFromHistory(); break;
        case 15: _t->clearEmailHistory(); break;
        case 16: _t->filterEmailHistory(); break;
        case 17: _t->sortEmailHistory((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 18: _t->searchOrdersList(); break;
        case 19: _t->sortOrdersList(); break;
        case 20: _t->exportListToPDF(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
